          
          //________________Chapter 01____________________//

// 1. Write a script to greet your website visitor using JS alert box.

// alert("Assalam-O-Alaikum");

// 2. Write a script to display following message on your web page:

// alert("Error! Please enter a valid password");

// 3. Write a script to display following message on your web page: (Hint : Use line break)

// alert("Welcome to JS Land\nHappy Coding");

// 4. Write a script to display following messages in sequence:

// alert("Welcome to JS Land");
// alert("Prevent this page from creating additinol dialogue");

// 5. Generate the following message through browser’s developer console:

// var a = "Hello... I can run JS through my browser's console"
// console.log(alert(a));

// 6. Make use of alerts in your new/existing HTML & CSS project.

// alert("Welcome");

          //________________Chapter 02____________________//


// 1. Declare a variable called username.

// var username;

// 2. Declare a variable called myName & assign to it a string that represents your Full Name.

// var myNAme = "Azhar Zafar";

// 3. Write script to
// a) Declare a JS variable, titled message.
// b) Assign “Hello World” to variable message
// c) Display the message in alert box.

// var message = "Hello World";
// alert(message);

// 4. Write a script to save student’s bio data in JS variables and show the data in alert boxes.

// var name = "Azhar";
// var age = "I am 25 year old";
// var skills = "Certified Mobile Application Development";

// alert(name);
// alert(age);
// alert(skills);

// 5. Write a script to display the following alert using one JS variable:

// var a = "PIZZA\nPIZZ\nPIZ\nPI\nP";
//     alert(a);

// 6. Declare a variable called email and assign to it a string that represents your Email Address(e.g. example@example.com). Show the blow mentioned message in an alert box.(Hint: use string concatenation)

// var b = "My email address is"
// var email = "azhar@gmail.com"
// alert(b +" " +email);

// 7. Declare a variable called book & give it the value “A smarter way to learn JavaScript”. Display the following message in an alert box:

// var c = "I am trying to learn from"
// var book = "A smarter way to learn JavaScript"
// alert(c +" " +book);

// 8. Write a script to display this in browser through JS

// document.write("Yah! I can write HTML content through JavaScript");

// 9. Store following string in a variable and show in alert and browser through JS “▬▬▬▬▬▬▬▬▬ஜ ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬”

// var str = "“▬▬▬▬▬▬▬▬▬ஜ ۩۞۩ ஜ▬▬▬▬▬▬▬▬▬”";
// alert(str);
// document.write(str);

          //________________Chapter 03____________________//
         
// 1. Declare a variable called age & assign to it your age. Show your age in an alert box.

// var age = 25;
// alert("I am " +age + " year old");

// 2. Declare & initialize a variable to keep track of how many times a visitor has visited a web page. Show his/her number of visits on your web page. For example: “You have visited this site N times”.

// var count = +prompt()
// alert(  "You have visited this site"+" "+count +" "+ "times");

// 3. Declare a variable called birthYear & assign to it your birth year. Show the following message in your browser:

// var birthYear = 1996;
// document.write("My Birth Year is " +birthYear);

// task 4. 

//  var name = prompt("enter your name")
//  var Quantity = +prompt("enter quantity")
//  var title = prompt("enter product title")
//  document.write(name+" "+"Order"+" "+Quantity+" "+title+" "+"on XYZClothing")

          //________________Chapter 04____________________//

// 1. Declare 3 variables in one statement.

// var one = 1; two = 3; three = 3;

// 2. Declare 5 legal & 5 illegal variable names.

// var _a = 1; -----> legal
// var nameOfBrand = 1; -----> legal
// var a1 = 1; -----> legal
// var a23a! = 1; -----> legal
// var _a%1 = 1; -----> illegal
// var a-1 =1; -----> illegal
// var a@apple = 1 -----> illegal
// var 1a =1; -----> illegal
// var Sp ce = 1; -----> illegal
// var @a = 1; -----> illegal

// 3.

// document.write("<h2>Rules for naming JS variables</h2><br>");
// document.write("<p>Variable names can only contain number, $, _ and For example $my_1stVariable.</p>");
// document.write("<p>Variables must begin with a letter, $ or _. For example $name, _name or name</p>");
// document.write("<p>Variable names are case sensitive</p>");
// document.write("<p>Variable names should not be JS Keywords</p>");

            //________________Chapter 05____________________//

// 1. Write a program that take two numbers & add them in a new variable. Show the result in your browser.

// var a = 3;
// var b = 5;
// var c = a + b;
// document.write("The sum of " +a +" and " +b +" is " +c);

// 2. Repeat task1 for subtraction, multiplication, division & modulus.

// var a = 3;
// var b = 5;
// var c = a - b;
// document.write("The subtraction of " +a +" and " +b +" is " +c);

// var a = 3;
// var b = 5;
// var c = a * b;
// document.write("The multipilication of " +a +" and " +b +" is " +c);

// var a = 3;
// var b = 5;
// var c = a / b;
// document.write("The divsion of " +a +" and " +b +" is " +c);

// var a = 3;
// var b = 5;
// var c = a % b;
// document.write("The modulus of " +a +" and " +b +" is " +c);

// 3. Do the following using JS Mathematic Expressions

// a. Declare a variable.

// var a;

// b. Show the value of variable in your browser like “Value after variable declaration is: ??”.

// document.write("Value after variable declaration is: " +a +"<br>");

// d. Show the value of variable in your browser like “Initial value: 5”.

// a = 5;
// document.write("Initial value: " +a +"<br>");

// e. Increment the variable.

// a++

// f. Show the value of variable in your browser like “Value after increment is: 6”.

// document.write("Value after increment is: " +a +"<br>");

// g. Add 7 to the variable.

// a + 7;

// h. Show the value of variable in your browser like “Value after addition is: 13”.

// document.write("Value after addition is: " +a +"<br>");

// i. Decrement the variable.



// j. Show the value of variable in your browser like “Value after decrement is: 12”.



// k. Show the remainder after dividing the variable’s value by 3.




// l. Output : “The remainder is : 0”.



// 4. Cost of one movie ticket is 600 PKR. Write a script to store ticket price in a variable & calculate the cost of buying 5 tickets to a movie. Example output:

// var cost = 600;
// var tickets = 5;

// var totalCost = cost * tickets;

// document.write("Total cost to buy 5 tickets to a movie is " +totalCost +"PKR");

// 5. Write a script to display multiplication table of any number in your browser. E.g

// var num = 4;

// for(var i = 1; i <= 10; i++){

//     var result = i * num;

//     document.write(num +" * " +i +" = " +result +"<br>");

// }

// The Temperature Converter: It’s hot out! Let’s make a converter based on the steps here.
// a. Store a Celsius temperature into a variable.

// var Celsius = 25;

// b. Convert it to Fahrenheit & output “NNoC is NNoF”.

// var Fahrenheit = 1.8 * Celsius + 32;
// document.write( Celsius + "C is " + Fahrenheit +"F" +"<br>");


// c. Now store a Fahrenheit temperature into a variable.

// var fahrenheit = 70;

// d. Convert it to Celsius & output “NNoF is NNoC”.

// var Celsius = (fahrenheit - 32) * 5/9;
// document.write( fahrenheit + "F is " + Celsius +"C" +"<br>");


// 7. Write a program to implement checkout process of a shopping cart system for an e-commerce website. Store the following in variables

// a. Price of item 

// var item1 = 650;
// document.write( "Price of item 1 is " +item1 +"<br>");

// b. Price of item 2 

// var item2 = 100;
// document.write( "Price of item 2 is " +item2 +"<br>");

// c. Ordered quantity of item 1 

// var quantity1  = 3;
// document.write( "quantity of item 1 is " +quantity1 +"<br>");


// d. Ordered Quantity of item 2 

// var quantity2  = 7;
// document.write( "quantity of item 2 is " +quantity2 +"<br>");


// e. Shipping charges

// var shippingCharges = 100;
// document.write( "Shipping Charges is " +shippingCharges +"<br>");

// Compute the total cost & show the receipt in your browser.

// var totalCost = item1 * quantity1 + item2 * quantity2 + shippingCharges;
// document.write( "Total Cost of your order is " +totalCost);

// 8. Store total marks & marks obtained by a student in 2 variables. Compute the percentage & show the result in your browser

// var totalMarks = 980;
// document.write( "Total marks: " +totalMarks +"<br>");

// var marksObtained = 804;
// document.write( "Marks obtained: " +marksObtained +"<br>");

// var percentage = marksObtained/totalMarks * 100;

// document.write( "Percentage: " +percentage +"%");

// 9. Assume we have 10 US dollars & 25 Saudi Riyals. Write a script to convert the total currency to Pakistani Rupees. Perform all calculations in a single expression. (Exchange rates : 1 US Dollar = 104.80 Pakistani Rupee and 1 Saudi Riyal = 28 Pakistani Rupee)

// var dollar = 10*104.80;
// var riyal = 25*28;

// document.write("<h1>Currency in PKR</h1>" +"<br>"+"<br>");
// var totalCurrency = dollar + riyal;
// document.write("Total Currncy  in PKR: " +totalCurrency);

// 10. Write a program to initialize a variable with some number and do arithmetic in following sequence:

// var a = 5; 

// a. Add 5 
// b. Multiply by 10 
// c. Divide the result by 2 Perform all calculations in a single expression

// var result = a + 5 * 10 / 2;
// document.write("Total Result is: " +result);

// 11. The Age Calculator: Forgot how old someone is? Calculate it! 
// a. Store the current year in a variable. 

// var currentYear = 2022;
// document.write("Current Year " +currentYear +"<br>");

// b. Store their birth year in a variable.

// var birthYear = 1996;
// document.write("Birth Year " +birthYear +"<br>");

// c. Calculate their 2 possible ages based on the stored values.

// var age = currentYear - birthYear;

// Output them to the screen like so: “They are either NN or NN years old”.

// document.write("Your age is: " +age);


// 12. The Geometrizer: Calculate properties of a circle. 
// a. Store a radius into a variable.
// b. Calculate the circumference based on the radius, and output “The circumference is NN”. (Hint : Circumference of a circle = 2 π r , π = 3.142) Calculate the area based on the radius, and output “The area is NN”. (Hint : Area of a circle = π r2, π = 3.142)


// 13. The Lifetime Supply Calculator: Ever wonder how much a “lifetime supply” of your favorite snack is? Wonder no more. 
//a. Store your favorite snack into a variable

// var favoriteSnack = "Chocolate Chip";
// document.write("Favorite Snack is : " +favoriteSnack +"<br>");

// b. Store your current age into a variable.
// var currentAge = "15";
// document.write("Current Age is : " +currentAge +"<br>");

// c. Store a maximum age into a variable.
// var maximumAge = "65";
// document.write("Estimated Maximum Age is : " +maximumAge +"<br>");

// d. Store an estimated amount per day (as a number).
// var amountOfSnack = "3";
// document.write("Amount Snack Per day is : " +amountOfSnack +"<br>");

// e. Calculate how many would you eat total for the rest of your life.
// Output the result to the screen like so: “You will need NNNN to last you until the ripe old age of NN”.
// var remainingAge = maximumAge - currentAge;
// var totalSnack = amountOfSnack * 364 * remainingAge ;
// document.write("You will need " +totalSnack +" Chocolate Chip");

            //________________Chapter 06 to 09____________________//

// 1. Write a program to take a number in a variable, do the required arithmetic to display the following result in your browser:
// document.write("<h1>Result</h1>" +"<br>"+"<br>")
// var a = 10;
// document.write("The Value of a is " +a +"<br>")
// document.write("----------------------------------------"+"<br>"+"<br>")

// ++a
// document.write("The Value of a is ++a is " +a +"<br>")
// document.write("Now the Value of a is " +a +"<br>"+"<br>")


// document.write("The Value of a is a++ is " +a +"<br>")
// a++ 
// document.write("Now the Value of a is " +a +"<br>"+"<br>")

// --a
// document.write("The Value of a is --a is " +a +"<br>")
// document.write("Now the Value of a is " +a +"<br>"+"<br>")

// document.write("The Value of a is a-- is " +a +"<br>")
// a-- 
// document.write("Now the Value of a is " +a +"<br>"+"<br>")

// 2. What will be the output in variables a, b & result after execution of the following script: var a = 2, b = 1; var result = --a - --b + ++b + b--; Explain the output at each stage: --a; --a - --b; --a - --b + ++b; --a - --b + ++b + b--;

// var a = 2, b = 1; 
// var result = --a - --b + ++b + b--;

// document.write("Result is " +result +"<br>");

// --a
// document.write("a is " +a +"<br>");

// var c= --a - --b;
// document.write("Result is " +c +"<br>");

// document.write("Result is " +result +"<br>");

// 3. Write a program that takes input a name from user & greet the user.

// var userName = prompt("Enter Name");
// document.write("Assalam-O-Alaikum " +userName);

// 5. Write a program to take input a number from user & display it’s multiplication table on your browser. If user does not enter a new number, multiplication table of 5 should be displayed by default.

// var num = prompt("Enter a Number fro table");
// for(var i = 1; i <= 10; i++){

//        var result = i * num;
    
//        document.write(num +" * " +i +" = " +result +"<br>");
    
//      }

// 6.
// a) Take three subjects name from user and store them in 3 different variables.
// b) Total marks for each subject is 100, store it in another variable.
// c) Take obtained marks for first subject from user and stored it in different variable.
// d) Take obtained marks for remaining 2 subjects from user and store them in variables.
// e) Now calculate total marks and percentage and show the result in browser like this.(Hint: user table)

               //________________Chapter 09 to 11____________________//

// 1. Write a program to take “city” name as input from user. If user enters “Karachi”, welcome the user like this: “Welcome to city of lights”

// var city = prompt("Enetr City Name:");
// if(city == "karachi"){
//     document.write("Welcome to city of lights")
// }
// else{
//     document.write("Pleasr Enter Correct city name")
// }

// 2. Write a program to take “gender” as input from user. If the user is male, give the message: Good Morning Sir. If the user is female, give the message: Good Morning Ma’am.

// var gender = prompt("Enetr gender: ");
// if(gender == "male"){
//     document.write("Good Morrning Sir");
// }
// else if(gender == "female"){
//     document.write("Good Morrning Ma'am");
// }
// else{
//     document.write("Error");
// }

// 3. Write a program to take input color of road traffic signal from the user & show the message according to this table:
    
// var color = prompt("Enter Color of road Signal");

// if(color == "red"){
//     document.write("Must Stop");
// }
// else if(color == "yellow"){
//     document.write("Ready to Move");
// }
// else if(color == "green"){
//     document.write("Move Now");
// }
// else{
//     document.write("Enter a correct color ");
// }

// 5. Run this script, & check whether alert message would be displayed or not. Record the outputs. 
//a. 
// var a = 4; 
// if (++a === 5){ 
//     alert("given condition for variable a is true"); 
// }

//b. 
// var b = 82; 
// if (b++ === 83){ 
//     alert("given condition for variable b is true"); 
// }
// c. 
// var c = 12; 
// if (c++ === 13){
//      alert("condition 1 is true"); 
// } if (c === 13){ 
//     alert("condition 2 is true"); 
// } 
// if (++c < 14){ 
//     alert("condition 3 is true"); 
// } if(c === 14){ 
//     alert("condition 4 is true"); 
// }
// // d. 
// var materialCost = 20000; 
// var laborCost = 2000; 
// var totalCost = materialCost + laborCost; 
// if (totalCost === laborCost + materialCost){ 
//     alert("The cost equals"); 
// }
// // e. 
// if (true){ 
//     alert("True"); 
// } 
// if (false){ 
//     alert("False"); 
// }
// // f. 
// if("car" < "cat"){
//      alert("car is smaller than cat"); 
//     }

// 6. Write a program to take input the marks obtained in three subjects & total marks. Compute & show the resulting percentage on your page. Take percentage & compute grade as per following table:


// var math = +prompt("Enter Your Math marks");
// var english = +prompt("Enter Your english marks");
// var urdu = +prompt("Enter Your urdu marks");


// var total_marks = math + english + urdu;

// document.write("Total marks = ",total_marks +"<br>");

// var percentage = total_marks/5;
// document.write("Persentage = ",percentage,"%");

// if(percentage >= 80 ){
//     document.write("A-One "+" Excelent");
//  }

//  else if(percentage >= 70 && percentage <= 80 ){
//     document.write("A "+" Good");
// }

// else if(percentage >= 60 && percentage <= 70 ){
//     document.write("B "+" You need to improve");
// }

// else{
//     console.log("Fail")
// }
// console.log("*************Marksheet*************");

// 8. Write a program to check whether the given number is divisible by 3. Show the message to the user if the number is divisible by 3.

//  var num = +prompt("Enter number");
// if (num % 3 == 0) {
//     document.write("Divisible")
//   } else {
//     document.write("not divisble") 
//   }

// chapter 12-13

// Q1)
// function check(ch) {
//     if (ch >= "A" && ch <= "Z")
//       document.write(ch +
//       " is an UpperCase character <br>");
//     else if (ch >= "a" && ch <= "z")
//       document.write(ch +
//       " is an LowerCase character <br>");
//     else document.write(ch +
//     " is not an aplhabetic character <br>");
//   } 
//   var ch;
//   ch = "A";

//   check(ch);

//   ch = "a";

//   check(ch);

//   ch = "0";

//   check(ch);


// Q2)

// var num1, num2;
// num1 = window.prompt("Input the First integer", "0");
// num2 = window.prompt("Input the second integer", "0");

// if(parseInt(num1, 10) > parseInt(num2, 10)) 
//   { 
//   console.log("The larger of "+ num1+ " and "+ num2+ " is "+ num1+ ".");
//   }   
// else if(parseInt(num2, 10) > parseInt(num1, 10)) 
//   {
//   console.log("The larger of "+ num1+" and "+ num2+ " is "+ num2+ ".");
//   }                  
// else
//   {
//    console.log("The values "+ num1+ " and "+num2+ " are equal.");
//   }

// Q3)
// var number = +prompt("Enter a number: ");

// if (number > 0) {
//     console.log("The number is positive");
// }

// else if (number == 0) {
//   console.log("The number is zero");
// }

// else {
//      console.log("The number is negative");
// }

// Q4)
// function isVowel(argument) {

//     var text;
//     var argument = argument.toLowerCase();

//     var vowels = (['a', 'e', 'i', 'o', 'u']);

//     for (var i = 0; i <= vowels.length; i++) {
//         if (argument != vowels[i]) {
//             continue;
//         }
//         return true;
//     }
//     return false;
// }

// var char = "A";

// if (isVowel(char)) {
//     console.log(char + " is a vowel");
// } else {
//     console.log(char + " is not a vowel");
// }

// Q5)
// function CheckPassword(inputtext) 
// { 
// var password=  /^[A-Za-z]\w{7,14}$/;
// if(inputtext.value.match(password)) 
// { 
// alert('Correct, try another...')
// return true;
// }
// else
// { 
// alert('Wrong...!')
// return false;
// }
// }

// Q6)
// var greeting;
// var hour = new Date().getHours();

// if (hour < 18) {

//     greeting = "Good day";
// }
// else{
//     greeting = "Good evening";

// }
// console.log(greeting)

// chapter 17-20

// Q1)
// var Arr=[[1,2],[3,4],[5,6]];

// Q3)
// for (var input = 1; input <= 10; input++) {
//     console.log(input);
//    }

// Q4)

// var number = +prompt('Enter an integer: ');

// for(let i = 1; i <= 10; i++) {

//     var result = i * number;

//     console.log(`${number} * ${i} = ${result}`);
// }

// Q5)
// var fruits = new Array("Apple", "Orange", "Mango", "Banana", "Guava");
// var len = fruits.length;
// for (var i = 0; i < len; i++) {
// 	console.log(fruits[i]);
// }


































